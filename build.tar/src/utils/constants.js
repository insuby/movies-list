export const CATALOG_ROUTE = '/'
export const PRODUCT_ROUTE = '/products'

